# Daily-Note
An Android notebook
